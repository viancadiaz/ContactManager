package com.example.contactmanager;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.util.List;

import Data.DatabaseHandler;
import Model.Contact;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DatabaseHandler db = new DatabaseHandler(this);


       Log.d("Insert: ", "Insertin...");
        /*db.addContact(new Contact("Paul", "4562857415"));
        db.addContact(new Contact("Riley", "1784523285"));
        db.addContact(new Contact("Pink", "475252415"));
        db.addContact(new Contact("Josh", "2365897412"));
        */
        Log.d("Reading: ", "Reading all contacts...");
        List<Contact> contactList = db.getAllContacts();

        //Contact oneContact = db.getContact(3);
       // oneContact.setName("Paulooo");
        //oneContact.setPhoneNumber("4529638547");

       // int newContact = db.updateContact(oneContact);

        //Log.d("One Contact: ", "Updated Row: " + String.valueOf(newContact) + "Name: " +oneContact.getName() + "Phone: " + oneContact.getPhoneNumber());

        Log.d("DB Count:", String.valueOf(db.getContactCount()));

        //db.deleteContact(oneContact);
        for (Contact c : contactList){
            String log = "ID: "+c.getId()+" , Name: " + c.getName() + ", Phone: "+ c.getPhoneNumber();

            Log.d("Name: ", log);
        }

    }
}
